package demo.demo.controller;

import demo.demo.entity.usuario;
import demo.demo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/usuario")
public class usuarioController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/cadastro")
    public String mostrarCadastro(Model model) {
        model.addAttribute("usuario", new usuario());
        return "cadastroUsuario";
    }

    @PostMapping("/salvar")
    public String salvarUsuario(@ModelAttribute usuario usuario) {
        usuarioRepository.save(usuario);
        return "redirect:/usuario/lista";
    }

    @GetMapping("/listaUsuarios")
    public String listaUsuarios(Model model) {
        model.addAttribute("usuarios", usuarioRepository.findAll());
        return "listaUsuarios";
    }

}
