package demo.demo.repository;

import demo.demo.entity.modeloVeiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface modeloVeiculoRepository extends JpaRepository<modeloVeiculo, Long> {
}
