package demo.demo.service;

import demo.demo.entity.usuario;
import demo.demo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;


    @Service
    public class UsuarioService {

        @Autowired
        private UsuarioRepository usuarioRepository;

        public usuario salvarUsuario(usuario usuario) {
            return usuarioRepository.save(usuario);
        }

        public List<usuario> listarUsuarios() {
            return usuarioRepository.findAll();
        }
    }


